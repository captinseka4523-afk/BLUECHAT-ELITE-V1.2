package com.bluechat.elite

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

private val Navy = Color(0xFF091522)
private val Panel = Color(0xFF122438)
private val Blue = Color(0xFF58B9E8)
private val Muted = Color(0xFF9CB0C2)

class MainActivity : ComponentActivity() {
    private val chat = BluetoothChat()
    private var adapter: BluetoothAdapter? = null
    private val found = mutableStateListOf<BluetoothDevice>()
    private var receiverRegistered = false

    private val discoveryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (BluetoothDevice.ACTION_FOUND == intent?.action) {
                val device = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                device?.let { if (found.none { d -> d.address == it.address }) found.add(it) }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        setContent {
            BlueChatApp(
                chat = chat,
                getAdapter = { adapter },
                found = found,
                onStartDiscovery = { startDiscovery() },
                onStartHost = { ensureConnectPermission { chat.startHost(adapter!!) } },
                onConnect = { d -> ensureConnectPermission { chat.connect(d) } },
                onEnableBluetooth = {
                    startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                }
            )
        }
    }

    private fun ensureConnectPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 501)
        } else action()
    }

    private fun startDiscovery() {
        val a = adapter ?: return
        val permissions = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 502)
            return
        }
        try {
            found.clear()
            if (a.isDiscovering) a.cancelDiscovery()
            if (!receiverRegistered) {
                val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
                if (Build.VERSION.SDK_INT >= 33) registerReceiver(discoveryReceiver, filter, RECEIVER_NOT_EXPORTED)
                else @Suppress("DEPRECATION") registerReceiver(discoveryReceiver, filter)
                receiverRegistered = true
            }
            a.startDiscovery()
        } catch (_: SecurityException) {}
    }

    override fun onDestroy() {
        try { if (receiverRegistered) unregisterReceiver(discoveryReceiver) } catch (_: Exception) {}
        chat.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BlueChatApp(
    chat: BluetoothChat,
    getAdapter: () -> BluetoothAdapter?,
    found: List<BluetoothDevice>,
    onStartDiscovery: () -> Unit,
    onStartHost: () -> Unit,
    onConnect: (BluetoothDevice) -> Unit,
    onEnableBluetooth: () -> Unit
) {
    val status by chat.status.collectAsState()
    val messages by chat.messages.collectAsState()
    var page by remember { mutableStateOf("chat") }
    var drawer by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var dark by remember { mutableStateOf(true) }
    var language by remember { mutableStateOf("العربية") }
    var lockEnabled by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkScheme()) {
        ModalNavigationDrawer(
            drawerState = androidx.compose.material3.rememberDrawerState(if (drawer) DrawerValue.Open else DrawerValue.Closed),
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = Panel) {
                    Spacer(Modifier.height(28.dp))
                    Text("BLUECHAT ELITE", color = Blue, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp))
                    listOf("المحادثة" to "chat", "الأجهزة القريبة" to "devices", "الإعدادات" to "settings", "حول التطبيق" to "about").forEach { (label, key) ->
                        NavigationDrawerItem(
                            label = { Text(label, color = Color.White) },
                            selected = page == key,
                            onClick = { page = key; drawer = false },
                            modifier = Modifier.padding(horizontal = 12.dp),
                            colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = Color(0xFF1E405A))
                        )
                    }
                }
            },
            gesturesEnabled = true
        ) {
            Scaffold(containerColor = Navy, topBar = {
                TopAppBar(
                    title = { Column {
                        Text("BlueChat Elite", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(status, color = Muted, fontSize = 11.sp)
                    } },
                    navigationIcon = { IconButton(onClick = { drawer = true }) { Icon(Icons.Default.Menu, null, tint = Color.White) } },
                    actions = { Icon(Icons.Default.Bluetooth, null, tint = Blue, modifier = Modifier.padding(end = 18.dp)) },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
                )
            }) { pad ->
                when (page) {
                    "chat" -> ChatScreen(messages, input, { input = it }, {
                        if (input.isNotBlank()) { chat.send(input); input = "" }
                    }, Modifier.padding(pad))
                    "devices" -> DevicesScreen(found, onStartDiscovery, onStartHost, onConnect, onEnableBluetooth, Modifier.padding(pad))
                    "settings" -> SettingsScreen(dark, { dark = it }, language, { language = it }, lockEnabled, { lockEnabled = it }, Modifier.padding(pad))
                    else -> AboutScreen(Modifier.padding(pad))
                }
            }
        }
    }
}

@Composable
private fun ChatScreen(messages: List<ChatMessage>, input: String, onInput: (String) -> Unit, onSend: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Text("المحادثات هنا محلية عبر Bluetooth Classic. ابدأ الاستضافة أو اتصل بجهاز من صفحة الأجهزة.", color = Muted, modifier = Modifier.padding(14.dp), fontSize = 13.sp)
        }
        Spacer(Modifier.height(14.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (msg.mine) Color(0xFF174E70) else Panel, shape = RoundedCornerShape(16.dp)) {
                        Text(msg.text, color = Color.White, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().background(Panel, CircleShape).padding(8.dp)) {
            BasicTextField(value = input, onValueChange = onInput, modifier = Modifier.weight(1f).padding(horizontal = 12.dp), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp), decorationBox = { inner ->
                if (input.isEmpty()) Text("اكتب رسالة...", color = Muted)
                inner()
            })
            IconButton(onClick = onSend) { Icon(Icons.Default.Send, null, tint = Blue) }
        }
    }
}

@Composable
private fun DevicesScreen(
    devices: List<BluetoothDevice>,
    scan: () -> Unit,
    host: () -> Unit,
    connect: (BluetoothDevice) -> Unit,
    enable: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("الاتصال بالأجهزة", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("يجب تشغيل Bluetooth على الهاتفين. سيطلب Android الإذن عند الحاجة.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = enable, colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("تشغيل Bluetooth", color = Navy) }
            OutlinedButton(onClick = scan) { Text("بحث عن أجهزة", color = Blue) }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = host, modifier = Modifier.fillMaxWidth()) { Text("استضافة اتصال (انتظار جهاز)", color = Blue) }
        Spacer(Modifier.height(18.dp))
        Text("الأجهزة المكتشفة", color = Color.White, fontWeight = FontWeight.SemiBold)
        LazyColumn {
            items(devices) { device ->
                DeviceRow(device, onClick = { connect(device) })
            }
        }
    }
}

@Suppress("MissingPermission")
@Composable
private fun DeviceRow(device: BluetoothDevice, onClick: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() }) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Bluetooth, null, tint = Blue)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(device.name ?: "جهاز Bluetooth", color = Color.White)
                Text(device.address ?: "", color = Muted, fontSize = 11.sp)
            }
            Text("اتصال", color = Blue, fontSize = 13.sp)
        }
    }
}

@Composable
private fun SettingsScreen(dark: Boolean, onDark: (Boolean) -> Unit, language: String, onLanguage: (String) -> Unit, lock: Boolean, onLock: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("الإعدادات", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        SettingRow("المظهر الداكن", dark) { onDark(it) }
        SettingRow("قفل التطبيق (واجهة تجريبية)", lock) { onLock(it) }
        Spacer(Modifier.height(16.dp))
        Text("اللغة", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = language == "العربية", onClick = { onLanguage("العربية") }, label = { Text("العربية") })
            FilterChip(selected = language == "English", onClick = { onLanguage("English") }, label = { Text("English") })
        }
        Spacer(Modifier.height(20.dp))
        Text("ملاحظة: تبديل اللغة والمظهر محفوظ داخل حالة الشاشة حاليًا؛ التخزين الدائم وقفل PIN والبصمة غير مفعّلين في هذه النسخة.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SettingRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun AboutScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("BlueChat Elite", color = Blue, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("مراسلة محلية دون إنترنت عبر Bluetooth Classic.", color = Color.White)
        Spacer(Modifier.height(12.dp))
        Text("هذه النسخة هي نواة اتصال أولية. لا تحتوي بعد على تشفير طرفي موثّق، BLE، Wi‑Fi Direct، المجموعات، نقل الوسائط أو خدمة خلفية مستمرة. لا تستخدمها لتبادل معلومات حساسة.", color = Muted)
    }
}

private fun darkScheme() = darkColorScheme(
    primary = Blue,
    background = Navy,
    surface = Panel,
    onPrimary = Navy,
    onBackground = Color.White,
    onSurface = Color.White
)
