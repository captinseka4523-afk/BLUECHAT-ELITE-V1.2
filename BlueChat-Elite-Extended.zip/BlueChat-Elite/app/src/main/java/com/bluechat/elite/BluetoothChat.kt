package com.bluechat.elite

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.util.UUID

/**
 * RFCOMM transport. Both phones must have BlueChat installed and one side must host.
 * This transport is local-range Bluetooth Classic; it is not an Internet messenger.
 */
class BluetoothChat {
    companion object {
        val SERVICE_UUID: UUID = UUID.fromString("a6b4d2e1-9c83-4d77-a45e-7b6f0d1c2a90")
        private const val SERVICE_NAME = "BlueChatElite"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var server: BluetoothServerSocket? = null
    private var socket: BluetoothSocket? = null
    private var writer: PrintWriter? = null
    private val incomingChannel = Channel<String>(Channel.BUFFERED)

    private val _status = MutableStateFlow("غير متصل")
    val status = _status.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages = _messages.asStateFlow()

    private val _devices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val devices = _devices.asStateFlow()

    fun setDevices(list: List<BluetoothDevice>) { _devices.value = list }

    @SuppressLint("MissingPermission")
    fun startHost(adapter: BluetoothAdapter) {
        scope.launch {
            try {
                closeConnection()
                _status.value = "بانتظار اتصال..."
                server = adapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, SERVICE_UUID)
                val accepted = server!!.accept()
                server?.close()
                server = null
                attach(accepted)
            } catch (e: Exception) {
                _status.value = "تعذر بدء الاستضافة: ${e.message ?: "خطأ"}"
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        scope.launch {
            try {
                closeConnection()
                _status.value = "جارٍ الاتصال..."
                val s = device.createRfcommSocketToServiceRecord(SERVICE_UUID)
                s.connect()
                attach(s)
            } catch (e: Exception) {
                _status.value = "فشل الاتصال: ${e.message ?: "تحقق من الاقتران"}"
                try { socket?.close() } catch (_: Exception) {}
            }
        }
    }

    private fun attach(s: BluetoothSocket) {
        socket = s
        writer = PrintWriter(s.outputStream, true)
        _status.value = "متصل: ${s.remoteDevice.name ?: "جهاز قريب"}"
        scope.launch {
            try {
                val reader = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8))
                while (true) {
                    val line = reader.readLine() ?: break
                    _messages.value = _messages.value + ChatMessage(line, false)
                }
            } catch (_: Exception) {
            } finally {
                _status.value = "انقطع الاتصال"
                try { s.close() } catch (_: Exception) {}
            }
        }
    }

    fun send(text: String) {
        scope.launch {
            val w = writer
            if (w == null || socket?.isConnected != true) {
                _status.value = "لا يوجد اتصال نشط"
                return@launch
            }
            try {
                // Newline-delimited framing; reject newlines to keep framing unambiguous.
                val safe = text.replace("\n", " ").replace("\r", " ").take(4000)
                w.println(safe)
                if (w.checkError()) throw IllegalStateException("تعذّر إرسال الرسالة")
                _messages.value = _messages.value + ChatMessage(safe, true)
            } catch (e: Exception) {
                _status.value = "فشل الإرسال: ${e.message}"
            }
        }
    }

    fun disconnect() {
        scope.launch { closeConnection(); _status.value = "غير متصل" }
    }

    private suspend fun closeConnection() {
        try { socket?.close() } catch (_: Exception) {}
        try { server?.close() } catch (_: Exception) {}
        socket = null
        server = null
        writer = null
    }

    fun shutdown() {
        scope.launch { closeConnection() }
        scope.cancel()
    }
}

data class ChatMessage(val text: String, val mine: Boolean)
