package com.bluechat.elite.model

import java.util.UUID

data class Conversation(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val isGroup: Boolean,
    val memberIds: Set<String>,
    val createdAt: Long = System.currentTimeMillis()
)

data class MessageRecord(
    val id: String = UUID.randomUUID().toString(),
    val conversationId: String,
    val senderId: String,
    val body: String,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long? = null,
    val replyToId: String? = null,
    val forwardedFromId: String? = null,
    val deliveryState: DeliveryState = DeliveryState.QUEUED
)

enum class DeliveryState { QUEUED, SENT, DELIVERED, READ, FAILED }

data class GroupInvite(val conversationId: String, val inviterId: String, val inviteeId: String)
