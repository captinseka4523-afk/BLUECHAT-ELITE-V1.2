package com.bluechat.elite.discovery

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings

/** BLE discovery helper. Requires BLUETOOTH_SCAN runtime permission on Android 12+. */
@SuppressLint("MissingPermission")
class BleDiscovery(adapter: BluetoothAdapter, private val onResult: (ScanResult) -> Unit) {
    private val scanner = adapter.bluetoothLeScanner
    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) = onResult(result)
        override fun onBatchScanResults(results: MutableList<ScanResult>) = results.forEach(onResult)
    }

    fun start() {
        scanner?.startScan(
            null,
            ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),
            callback
        )
    }

    fun stop() { scanner?.stopScan(callback) }
}
