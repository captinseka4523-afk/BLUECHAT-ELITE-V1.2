package com.bluechat.elite.security

import android.util.Base64
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * AES-256-GCM message envelope.
 * Pairing secret must be exchanged out-of-band (e.g. verified QR) and stored securely.
 * This primitive is not a complete audited end-to-end protocol or identity system.
 */
object SecureCodec {
    private const val NONCE_BYTES = 12
    private const val TAG_BITS = 128
    private const val MAX_PLAINTEXT = 1024 * 1024
    private val random = SecureRandom()

    fun newPairingSecret(): String {
        val bytes = ByteArray(32).also(random::nextBytes)
        return Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }

    private fun key(secret: String): SecretKeySpec {
        val raw = Base64.decode(secret, Base64.URL_SAFE or Base64.NO_WRAP)
        require(raw.size >= 32) { "Pairing secret must contain at least 256 bits" }
        val digest = MessageDigest.getInstance("SHA-256").digest(raw)
        return SecretKeySpec(digest, "AES")
    }

    fun encrypt(secret: String, plaintext: ByteArray, aad: ByteArray = byteArrayOf()): ByteArray {
        require(plaintext.size <= MAX_PLAINTEXT) { "Payload too large" }
        val nonce = ByteArray(NONCE_BYTES).also(random::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(secret), GCMParameterSpec(TAG_BITS, nonce))
        if (aad.isNotEmpty()) cipher.updateAAD(aad)
        val encrypted = cipher.doFinal(plaintext)
        return ByteBuffer.allocate(1 + nonce.size + encrypted.size)
            .put(1).put(nonce).put(encrypted).array()
    }

    fun decrypt(secret: String, envelope: ByteArray, aad: ByteArray = byteArrayOf()): ByteArray {
        require(envelope.size in (1 + NONCE_BYTES + 16)..(1 + NONCE_BYTES + MAX_PLAINTEXT + 16))
        val buffer = ByteBuffer.wrap(envelope)
        require(buffer.get().toInt() == 1) { "Unsupported envelope version" }
        val nonce = ByteArray(NONCE_BYTES).also(buffer::get)
        val ciphertext = ByteArray(buffer.remaining()).also(buffer::get)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(secret), GCMParameterSpec(TAG_BITS, nonce))
        if (aad.isNotEmpty()) cipher.updateAAD(aad)
        return cipher.doFinal(ciphertext)
    }
}
