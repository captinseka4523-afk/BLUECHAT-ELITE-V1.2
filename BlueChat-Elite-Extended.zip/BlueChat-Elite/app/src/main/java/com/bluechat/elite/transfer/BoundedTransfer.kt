package com.bluechat.elite.transfer

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * Length-prefixed binary transfer helpers. Always enforce a cap before allocating.
 * Call from an IO dispatcher and write received data to a file, not a giant byte array.
 */
object BoundedTransfer {
    const val MAX_FILE_BYTES: Long = 100L * 1024L * 1024L
    private const val BUFFER_SIZE = 32 * 1024

    fun send(input: InputStream, output: OutputStream, declaredSize: Long) {
        require(declaredSize in 0..MAX_FILE_BYTES) { "File exceeds transfer limit" }
        val data = DataOutputStream(output)
        data.writeLong(declaredSize)
        val buffer = ByteArray(BUFFER_SIZE)
        var remaining = declaredSize
        while (remaining > 0) {
            val count = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
            require(count >= 0) { "Source ended before declared size" }
            data.write(buffer, 0, count)
            remaining -= count
        }
        data.flush()
    }

    fun receive(input: InputStream, output: OutputStream): Long {
        val data = DataInputStream(input)
        val size = data.readLong()
        require(size in 0..MAX_FILE_BYTES) { "Rejected invalid or oversized transfer" }
        val buffer = ByteArray(BUFFER_SIZE)
        var remaining = size
        while (remaining > 0) {
            val count = data.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
            require(count >= 0) { "Connection ended during transfer" }
            output.write(buffer, 0, count)
            remaining -= count
        }
        output.flush()
        return size
    }
}
