package com.bluechat.elite.security

import java.io.InputStream
import java.io.OutputStream

/** Streaming backup encryption wrapper; caller supplies a high-entropy backup key. */
object EncryptedBackup {
    fun encrypt(input: InputStream, output: OutputStream, secret: String) {
        val plain = input.readBytes()
        output.write(SecureCodec.encrypt(secret, plain, "BlueChatBackupV1".toByteArray()))
        output.flush()
    }

    fun decrypt(input: InputStream, output: OutputStream, secret: String) {
        val encrypted = input.readBytes()
        output.write(SecureCodec.decrypt(secret, encrypted, "BlueChatBackupV1".toByteArray()))
        output.flush()
    }
}
