package com.bluechat.elite.transfer

import android.content.Context
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Looper

/** Wi-Fi Direct group creation/peer discovery controller. File socket protocol is separate. */
class WifiDirectController(context: Context) {
    private val manager = context.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private val channel = manager.initialize(context, Looper.getMainLooper(), null)

    fun discover(onStarted: (Boolean, String?) -> Unit) {
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = onStarted(true, null)
            override fun onFailure(reason: Int) = onStarted(false, "Wi-Fi Direct discovery failed: $reason")
        })
    }

    fun connect(address: String, onResult: (Boolean, String?) -> Unit) {
        val config = WifiP2pConfig().apply { deviceAddress = address }
        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = onResult(true, null)
            override fun onFailure(reason: Int) = onResult(false, "Wi-Fi Direct connection failed: $reason")
        })
    }

    fun createGroup(onResult: (Boolean, String?) -> Unit) {
        manager.createGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = onResult(true, null)
            override fun onFailure(reason: Int) = onResult(false, "Wi-Fi Direct group failed: $reason")
        })
    }
}
